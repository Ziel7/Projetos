# 🏪 Controle Comercial

Sistema de gestão comercial desenvolvido com Python + Streamlit + SQLite3.

---

## 📁 Estrutura de Arquivos

```
controle_comercial/
├── main.py              ← Ponto de entrada (execute este arquivo)
├── crud_db.py           ← Módulo de banco de dados (CRUD genérico)
├── requirements.txt     ← Dependências do projeto
├── crud_db.db           ← Banco de dados (criado automaticamente)
├── log.txt              ← Log de operações (criado automaticamente)
├── logo.jpg             ← Logo do sistema (opcional)
└── pages/
    ├── 1_Clientes.py    ← Gestão de clientes
    ├── 2_Produtos.py    ← Gestão de produtos e estoque
    ├── 3_Vendas.py      ← Registro de vendas
    ├── 4_Relatorios.py  ← Relatórios e análises
    └── 5_Sobre.py       ← Informações do sistema
```

---

## 🚀 Guia de Instalação e Execução

### 1. Pré-requisito

Certifique-se de ter o **Python 3.10+** instalado:

```bash
python --version
```

---

### 2. Criar o Ambiente Virtual

Dentro da pasta `controle_comercial/`, execute:

```bash
python -m venv venv
```

---

### 3. Ativar o Ambiente Virtual

**Windows (CMD ou PowerShell):**
```bash
venv\Scripts\activate
```

**Linux / macOS:**
```bash
source venv/bin/activate
```

> O terminal deve exibir `(venv)` na frente do prompt quando ativado.

---

### 4. Instalar as Dependências

```bash
pip install -r requirements.txt
```

---

### 5. Executar o Sistema

```bash
streamlit run main.py
```

O Streamlit abrirá automaticamente no navegador em:
```
http://localhost:8501
```

---

## ✅ Funcionalidades

| Módulo        | Funcionalidades                                          |
|---------------|----------------------------------------------------------|
| 👤 Clientes   | Cadastrar, listar, editar, excluir                       |
| 📦 Produtos   | Cadastrar, listar, editar, controle de estoque, excluir  |
| 💰 Vendas     | Registrar venda, histórico, cancelar venda               |
| 📈 Relatórios | Vendas, ranking de produtos, ranking de clientes, estoque|
| ℹ️ Sobre      | Informações do sistema, log de operações                 |

---

## 📝 Observações

- O banco de dados `crud_db.db` é criado automaticamente na primeira execução.
- O arquivo `log.txt` registra todas as operações CRUD e erros.
- Coloque uma imagem `logo.jpg` na raiz do projeto para exibir no sistema.
- Compatível com **Windows 10/11**, **Linux** e **macOS**.

---

## 🛠️ Tecnologias Utilizadas

- **Python 3.10+**
- **Streamlit** — Interface web multipágina
- **SQLite3** — Banco de dados embutido
- **Pandas** — Análise e exibição de dados
- **Logging** — Registro de operações
- **Pathlib** — Manipulação de caminhos de arquivo
