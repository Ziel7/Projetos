# /////////////////////////////////////////////////////
# // Instituição  : SENAI
# // Disciplina   : Projeto Integrador
# // Nome Projeto : Controle Comercial
# // Aluno        : Gabriel Florentino
# // Data Atual   : 29/04/2026
# /////////////////////////////////////////////////////

"""
crud_db.py - Módulo de acesso ao banco de dados SQLite3
Contém todas as funções que criam, leem, atualizam e excluem registros
(operações CRUD: Create, Read, Update, Delete).
"""

# ─── IMPORTAÇÃO DAS BIBLIOTECAS ────────────────────────────────────────────────
import sqlite3             # sqlite3: banco de dados embutido no Python, sem instalação extra
import logging             # logging: registra eventos e erros em arquivo de log
import os                  # os: acessa informações e caminhos do sistema operacional
from pathlib import Path   # Path: manipulação moderna e multiplataforma de caminhos

# ─── CONFIGURAÇÃO DO LOGGING ──────────────────────────────────────────────────
# Configura o sistema de log para gravar eventos no arquivo log.txt.
# Cada operação no banco (INSERT, SELECT, UPDATE, DELETE) é registrada.
logging.basicConfig(
    filename="log.txt",                               # Arquivo de saída dos logs
    level=logging.INFO,                               # Nível mínimo: INFO e acima
    format="%(asctime)s [%(levelname)s] %(message)s", # Formato: data [NÍVEL] mensagem
    datefmt="%Y-%m-%d %H:%M:%S",                     # Formato da data no log
    encoding="utf-8",                                 # Suporte a caracteres especiais
)

# ─── CAMINHO DO BANCO DE DADOS ────────────────────────────────────────────────
# Path(__file__).parent aponta para a pasta onde este arquivo (crud_db.py) está.
# Assim, o banco de dados é sempre criado na mesma pasta do projeto.
DB_PATH = Path(__file__).parent / "crud_db.db"  # Caminho absoluto do arquivo .db

# Exibe no log o caminho completo do banco ao iniciar (útil para depuração)
logging.info(f"Banco de dados localizado em: {DB_PATH}")

# Verifica via os se a pasta onde o banco será criado existe (segurança extra)
os.makedirs(os.path.dirname(str(DB_PATH)), exist_ok=True)


# ─── FUNÇÃO: OBTER CONEXÃO ────────────────────────────────────────────────────
def get_connection() -> sqlite3.Connection:
    """
    Cria e retorna uma conexão com o banco de dados SQLite3.

    row_factory = sqlite3.Row transforma os resultados em objetos acessíveis
    tanto por índice (row[0]) quanto por nome de coluna (row["nome"]).

    Retorna:
        sqlite3.Connection: objeto de conexão ativo com o banco.
    """
    conn = sqlite3.connect(DB_PATH)          # Abre (ou cria) o arquivo .db
    conn.row_factory = sqlite3.Row           # Resultados acessíveis por nome de coluna
    conn.execute("PRAGMA foreign_keys = ON") # Ativa verificação de chaves estrangeiras
    return conn                              # Retorna a conexão pronta para uso


# ─── FUNÇÃO: INICIALIZAR O BANCO ─────────────────────────────────────────────
def inicializar_banco():
    """
    Cria as tabelas do banco de dados caso ainda não existam.

    Tabelas criadas:
        - clientes: id, nome, telefone, email
        - produtos:  id, nome, preco, estoque
        - vendas:    id, cliente_id, produto_id, qtd, total, data

    O comando CREATE TABLE IF NOT EXISTS garante que o banco não será
    recriado se já existir — apenas cria o que está faltando.
    """
    try:
        # "with" garante que a conexão será fechada mesmo se ocorrer erro
        with get_connection() as conn:
            cursor = conn.cursor()  # cursor é usado para executar comandos SQL

            # ── Tabela: clientes ──────────────────────────────────────────────
            # Armazena os dados dos clientes do sistema.
            # INTEGER PRIMARY KEY AUTOINCREMENT: ID gerado automaticamente (1, 2, 3...)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS clientes (
                    id       INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome     TEXT    NOT NULL,
                    telefone TEXT,
                    email    TEXT
                )
            """)

            # ── Tabela: produtos ──────────────────────────────────────────────
            # Armazena o catálogo de produtos com preço e estoque.
            # DEFAULT 0.0 e DEFAULT 0: valores padrão se não forem informados.
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS produtos (
                    id      INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome    TEXT    NOT NULL,
                    preco   REAL    NOT NULL DEFAULT 0.0,
                    estoque INTEGER NOT NULL DEFAULT 0
                )
            """)

            # ── Tabela: vendas ────────────────────────────────────────────────
            # Registra cada venda feita, relacionando cliente e produto.
            # FOREIGN KEY: garante que cliente_id e produto_id existam nas tabelas referenciadas.
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS vendas (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    cliente_id  INTEGER NOT NULL,
                    produto_id  INTEGER NOT NULL,
                    qtd         INTEGER NOT NULL DEFAULT 1,
                    total       REAL    NOT NULL DEFAULT 0.0,
                    data        TEXT    NOT NULL,
                    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
                    FOREIGN KEY (produto_id) REFERENCES produtos(id)
                )
            """)

            conn.commit()  # Confirma e salva as alterações no banco
            logging.info("Banco de dados inicializado com sucesso.")

    except Exception as e:
        # Se algo der errado, registra o erro e relança a exceção para o chamador
        logging.error(f"Erro ao inicializar banco: {e}")
        raise


# ─── FUNÇÃO: INSERT (CRIAR) ───────────────────────────────────────────────────
def insert(tabela: str, dados: dict) -> int | None:
    """
    Insere um novo registro em qualquer tabela do banco.

    Parâmetros:
        tabela (str):  Nome da tabela onde o registro será inserido.
        dados  (dict): Dicionário com os dados. Chave = coluna, Valor = valor.
                       Exemplo: {"nome": "João", "telefone": "99999-9999"}

    Retorna:
        int:  ID do registro recém-inserido (gerado automaticamente).
        None: Se ocorreu algum erro durante a inserção.

    Exemplo de SQL gerado:
        INSERT INTO clientes (nome, telefone) VALUES (?, ?)
    """
    # Monta dinamicamente os nomes das colunas separados por vírgula
    colunas = ", ".join(dados.keys())

    # Cria um "?" para cada valor (placeholders evitam SQL Injection)
    placeholders = ", ".join(["?" for _ in dados])

    # Lista com os valores na mesma ordem das colunas
    valores = list(dados.values())

    # Monta o comando SQL completo
    sql = f"INSERT INTO {tabela} ({colunas}) VALUES ({placeholders})"

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, valores)    # Executa o INSERT com os valores
            conn.commit()                   # Salva a alteração no banco
            novo_id = cursor.lastrowid      # Pega o ID do registro inserido
            logging.info(f"INSERT em '{tabela}' | ID={novo_id} | Dados={dados}")
            return novo_id                  # Retorna o ID gerado

    except Exception as e:
        logging.error(f"Erro no INSERT em '{tabela}': {e} | Dados={dados}")
        return None  # Retorna None para indicar falha


# ─── FUNÇÃO: SELECT (LER) ────────────────────────────────────────────────────
def select(tabela: str, condicoes: dict | None = None, colunas: str = "*") -> list[dict]:
    """
    Busca registros em qualquer tabela do banco.

    Parâmetros:
        tabela     (str):  Nome da tabela a ser consultada.
        condicoes  (dict): Filtros WHERE. Ex: {"id": 5} → WHERE id = 5 (opcional).
        colunas    (str):  Colunas a retornar. Padrão "*" = todas as colunas.

    Retorna:
        list[dict]: Lista de dicionários. Cada dicionário = um registro.
                    Retorna lista vazia [] se não encontrar ou ocorrer erro.

    Exemplo de SQL gerado:
        SELECT * FROM clientes WHERE id = ?
    """
    sql = f"SELECT {colunas} FROM {tabela}"  # Início do comando SELECT
    valores = []  # Lista de valores para os placeholders "?"

    # Se forem informadas condições, monta a cláusula WHERE dinamicamente
    if condicoes:
        # "col = ?" para cada chave do dicionário de condições
        where = " AND ".join([f"{col} = ?" for col in condicoes.keys()])
        sql += f" WHERE {where}"             # Adiciona o WHERE ao SQL
        valores = list(condicoes.values())   # Valores para preencher os "?"

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, valores)  # Executa o SELECT com os filtros

            # dict(row) converte cada sqlite3.Row em um dicionário Python comum
            resultado = [dict(row) for row in cursor.fetchall()]
            logging.info(f"SELECT em '{tabela}' | {len(resultado)} registro(s) | Condições={condicoes}")
            return resultado  # Retorna a lista de registros encontrados

    except Exception as e:
        logging.error(f"Erro no SELECT em '{tabela}': {e}")
        return []  # Retorna lista vazia em caso de erro


# ─── FUNÇÃO: UPDATE (ATUALIZAR) ──────────────────────────────────────────────
def update(tabela: str, dados: dict, condicoes: dict) -> bool:
    """
    Atualiza registros existentes em qualquer tabela do banco.

    Parâmetros:
        tabela     (str):  Nome da tabela a ser atualizada.
        dados      (dict): Campos a atualizar. Ex: {"nome": "Maria"}.
        condicoes  (dict): Filtros para identificar qual registro atualizar.
                           Ex: {"id": 3} → atualiza o registro com id = 3.

    Retorna:
        bool: True se ao menos um registro foi atualizado, False caso contrário.

    Exemplo de SQL gerado:
        UPDATE clientes SET nome = ? WHERE id = ?
    """
    # "col = ?" para cada campo a ser atualizado
    set_clause   = ", ".join([f"{col} = ?" for col in dados.keys()])

    # "col = ?" para cada condição do WHERE
    where_clause = " AND ".join([f"{col} = ?" for col in condicoes.keys()])

    # Os valores do SET vêm primeiro, depois os do WHERE
    valores = list(dados.values()) + list(condicoes.values())

    sql = f"UPDATE {tabela} SET {set_clause} WHERE {where_clause}"

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, valores)  # Executa o UPDATE
            conn.commit()                 # Salva a alteração

            # cursor.rowcount informa quantas linhas foram afetadas
            logging.info(f"UPDATE em '{tabela}' | Dados={dados} | Condições={condicoes}")
            return cursor.rowcount > 0    # True = pelo menos 1 registro alterado

    except Exception as e:
        logging.error(f"Erro no UPDATE em '{tabela}': {e}")
        return False  # Retorna False para indicar falha


# ─── FUNÇÃO: DELETE (EXCLUIR) ────────────────────────────────────────────────
def delete(tabela: str, condicoes: dict) -> bool:
    """
    Remove registros de qualquer tabela do banco.

    Parâmetros:
        tabela    (str):  Nome da tabela de onde excluir.
        condicoes (dict): Filtros para identificar qual registro excluir.
                          Ex: {"id": 7} → deleta o registro com id = 7.

    Retorna:
        bool: True se ao menos um registro foi removido, False caso contrário.

    Exemplo de SQL gerado:
        DELETE FROM clientes WHERE id = ?
    """
    # Monta a cláusula WHERE com todos os filtros informados
    where_clause = " AND ".join([f"{col} = ?" for col in condicoes.keys()])
    valores = list(condicoes.values())  # Valores dos filtros

    sql = f"DELETE FROM {tabela} WHERE {where_clause}"

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, valores)  # Executa o DELETE
            conn.commit()                 # Confirma a exclusão

            logging.info(f"DELETE em '{tabela}' | Condições={condicoes}")
            return cursor.rowcount > 0    # True = pelo menos 1 registro removido

    except Exception as e:
        logging.error(f"Erro no DELETE em '{tabela}': {e}")
        return False


# ─── FUNÇÃO: SELECT COM JOIN (RELATÓRIOS) ────────────────────────────────────
def select_vendas_completo(filtro_cliente: str = "", filtro_produto: str = "") -> list[dict]:
    """
    Retorna todas as vendas enriquecidas com nome do cliente e produto.
    Usa JOIN para combinar dados das tabelas vendas, clientes e produtos.

    Parâmetros:
        filtro_cliente (str): Filtra pelo nome do cliente (busca parcial, opcional).
        filtro_produto (str): Filtra pelo nome do produto (busca parcial, opcional).

    Retorna:
        list[dict]: Lista de vendas com campos: id, cliente, produto, qtd, total, data.

    Exemplo de SQL gerado:
        SELECT v.id, c.nome AS cliente, p.nome AS produto, v.qtd, v.total, v.data
        FROM vendas v
        JOIN clientes c ON v.cliente_id = c.id
        JOIN produtos p ON v.produto_id = p.id
        WHERE c.nome LIKE ? AND p.nome LIKE ?
        ORDER BY v.data DESC
    """
    # SQL base com JOIN para buscar dados de três tabelas ao mesmo tempo
    sql = """
        SELECT
            v.id,
            c.nome  AS cliente,
            p.nome  AS produto,
            v.qtd,
            v.total,
            v.data
        FROM vendas v
        JOIN clientes c ON v.cliente_id = c.id
        JOIN produtos p ON v.produto_id = p.id
        WHERE 1=1
    """
    valores = []  # Acumula os valores dos filtros dinâmicos

    # Se filtro_cliente foi informado, adiciona condição LIKE ao SQL
    # LIKE com % permite busca parcial: "jo" encontra "João", "Josefa", etc.
    if filtro_cliente:
        sql += " AND c.nome LIKE ?"
        valores.append(f"%{filtro_cliente}%")  # % antes e depois = busca em qualquer posição

    # Se filtro_produto foi informado, adiciona condição LIKE ao SQL
    if filtro_produto:
        sql += " AND p.nome LIKE ?"
        valores.append(f"%{filtro_produto}%")

    # Ordena do mais recente para o mais antigo
    sql += " ORDER BY v.data DESC"

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, valores)  # Executa o SELECT com JOIN e filtros
            resultado = [dict(row) for row in cursor.fetchall()]
            logging.info(f"SELECT vendas completo | {len(resultado)} registro(s)")
            return resultado

    except Exception as e:
        logging.error(f"Erro no SELECT de vendas completo: {e}")
        return []


# ─── INICIALIZAÇÃO AUTOMÁTICA ─────────────────────────────────────────────────
# Esta linha é executada automaticamente quando o módulo é importado.
# Garante que as tabelas existam antes de qualquer operação no banco.
inicializar_banco()
