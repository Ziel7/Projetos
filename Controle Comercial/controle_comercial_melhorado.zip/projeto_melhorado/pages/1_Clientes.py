# /////////////////////////////////////////////////////
# // Instituição  : SENAI
# // Disciplina   : Projeto Integrador
# // Nome Projeto : Controle Comercial
# // Aluno        : Gabriel Florentino
# // Data Atual   : 29/04/2026
# /////////////////////////////////////////////////////

"""
pages/1_Clientes.py - Tela de gerenciamento de clientes
Permite cadastrar, listar, editar e excluir clientes do sistema.
"""

# ─── IMPORTAÇÃO DAS BIBLIOTECAS ────────────────────────────────────────────────
import streamlit as st    # Streamlit: cria toda a interface web desta página
import sys                # sys: permite adicionar diretórios ao caminho de importação
import os                 # os: acessa informações do sistema operacional
from pathlib import Path  # Path: manipulação de caminhos de arquivos

# Adiciona a pasta raiz do projeto ao sys.path para que crud_db possa ser importado
# Sem isso, o Python não encontraria o arquivo crud_db.py (que está na pasta pai)
sys.path.insert(0, str(Path(__file__).parent.parent))
import crud_db  # Importa o módulo com as funções de banco de dados (CRUD)

# ─── CONSTANTES DA PÁGINA ─────────────────────────────────────────────────────
NOME_TABELA = "clientes"  # Nome da tabela no banco que esta página gerencia

# ─── CONFIGURAÇÃO DA PÁGINA ───────────────────────────────────────────────────
# Define título e ícone individuais para esta página.
st.set_page_config(
    page_title="Clientes | Controle Comercial",
    page_icon="👤",
    layout="wide"
)

# ─── CABEÇALHO ────────────────────────────────────────────────────────────────
st.markdown("# 👤 Clientes")
st.markdown("Gerencie o cadastro de clientes do sistema.")
st.divider()

# ─── ABAS DE NAVEGAÇÃO ────────────────────────────────────────────────────────
# st.tabs() cria abas clicáveis, separando as funcionalidades da página.
# Retorna um objeto para cada aba, usado no bloco "with" abaixo.
aba_cadastrar, aba_listar, aba_editar, aba_excluir = st.tabs([
    "➕ Cadastrar", "📋 Listar", "✏️ Editar", "🗑️ Excluir"
])

# ════════════════════════════════════════════════════════════════════════════════
# ABA: CADASTRAR NOVO CLIENTE
# ════════════════════════════════════════════════════════════════════════════════
with aba_cadastrar:
    st.subheader("Novo Cliente")

    # st.columns(2) divide o formulário em 2 colunas iguais lado a lado
    col1, col2 = st.columns(2)

    with col1:
        # st.text_input() cria um campo de texto. O placeholder é o texto cinza de exemplo.
        nome     = st.text_input("Nome *",     placeholder="Ex: João da Silva")
        telefone = st.text_input("Telefone",   placeholder="Ex: (82) 99999-9999")

    with col2:
        email = st.text_input("E-mail", placeholder="Ex: joao@email.com")

    # Botão de salvar: type="primary" deixa o botão com cor de destaque
    if st.button("💾 Salvar Cliente", type="primary", use_container_width=True):
        if not nome.strip():
            # .strip() remove espaços extras; se ficar vazio, o nome é inválido
            st.error("O campo **Nome** é obrigatório.")
        else:
            # Chama a função insert() do crud_db passando um dicionário com os dados
            novo_id = crud_db.insert(NOME_TABELA, {
                "nome":     nome.strip(),
                "telefone": telefone.strip(),
                "email":    email.strip(),
            })
            if novo_id:
                st.success(f"✅ Cliente **{nome}** cadastrado com sucesso! (ID: {novo_id})")
                st.balloons()  # Animação de balões para feedback visual positivo
            else:
                st.error("❌ Erro ao cadastrar cliente. Verifique o log.")

# ════════════════════════════════════════════════════════════════════════════════
# ABA: LISTAR CLIENTES
# ════════════════════════════════════════════════════════════════════════════════
with aba_listar:
    st.subheader("Lista de Clientes")

    # Busca todos os clientes do banco usando a função select() do crud_db
    clientes = crud_db.select(NOME_TABELA)

    if not clientes:
        st.info("Nenhum cliente cadastrado ainda.")
    else:
        import pandas as pd  # pandas: converte a lista de dicionários em tabela (DataFrame)
        df = pd.DataFrame(clientes)             # Cria o DataFrame com os dados
        df.columns = ["ID", "Nome", "Telefone", "E-mail"]  # Renomeia as colunas

        # Campo de busca por nome: filtra a tabela em tempo real
        busca = st.text_input("🔍 Buscar por nome", placeholder="Digite parte do nome...")
        if busca:
            # str.contains() filtra linhas que contenham o texto digitado (case=False = ignora maiúsc.)
            df = df[df["Nome"].str.contains(busca, case=False, na=False)]

        # st.dataframe exibe a tabela interativa; hide_index=True esconde a coluna de índice
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.caption(f"Total: {len(df)} cliente(s)")  # Rodapé com contador de resultados

# ════════════════════════════════════════════════════════════════════════════════
# ABA: EDITAR CLIENTE
# ════════════════════════════════════════════════════════════════════════════════
with aba_editar:
    st.subheader("Editar Cliente")

    clientes = crud_db.select(NOME_TABELA)  # Busca todos os clientes do banco

    if not clientes:
        st.info("Nenhum cliente cadastrado ainda.")
    else:
        # Cria um dicionário mapeando o label do selectbox ao objeto do cliente
        # Formato do label: "[1] João da Silva"
        opcoes = {f"[{c['id']}] {c['nome']}": c for c in clientes}

        # st.selectbox() exibe uma lista suspensa para o usuário escolher
        selecionado_label = st.selectbox("Selecione o cliente para editar:", list(opcoes.keys()))
        cliente_sel = opcoes[selecionado_label]  # Pega o dicionário do cliente selecionado

        col1, col2 = st.columns(2)
        with col1:
            # value= pré-preenche o campo com o valor atual do cliente
            novo_nome = st.text_input("Nome *",    value=cliente_sel["nome"])
            novo_tel  = st.text_input("Telefone",  value=cliente_sel.get("telefone") or "")
        with col2:
            novo_email = st.text_input("E-mail",   value=cliente_sel.get("email") or "")

        if st.button("💾 Atualizar Cliente", type="primary", use_container_width=True):
            if not novo_nome.strip():
                st.error("O campo **Nome** é obrigatório.")
            else:
                # Chama update() passando os novos dados e o ID como condição
                sucesso = crud_db.update(
                    NOME_TABELA,
                    dados={"nome": novo_nome.strip(), "telefone": novo_tel.strip(), "email": novo_email.strip()},
                    condicoes={"id": cliente_sel["id"]}  # Atualiza apenas o cliente com esse ID
                )
                if sucesso:
                    st.success(f"✅ Cliente **{novo_nome}** atualizado com sucesso!")
                    st.rerun()  # Recarrega a página para refletir as mudanças
                else:
                    st.error("❌ Erro ao atualizar cliente. Verifique o log.")

# ════════════════════════════════════════════════════════════════════════════════
# ABA: EXCLUIR CLIENTE
# ════════════════════════════════════════════════════════════════════════════════
with aba_excluir:
    st.subheader("Excluir Cliente")

    clientes = crud_db.select(NOME_TABELA)  # Busca todos os clientes

    if not clientes:
        st.info("Nenhum cliente cadastrado ainda.")
    else:
        opcoes = {f"[{c['id']}] {c['nome']}": c for c in clientes}

        # key= é necessário quando há dois selectbox na mesma página para evitar conflito
        selecionado_label = st.selectbox(
            "Selecione o cliente para excluir:",
            list(opcoes.keys()),
            key="excluir_cliente"  # Chave única para este selectbox
        )
        cliente_sel = opcoes[selecionado_label]

        # Aviso visual em amarelo sobre a ação irreversível
        st.warning(f"⚠️ Você está prestes a excluir: **{cliente_sel['nome']}**")

        # Checkbox de confirmação: botão só fica ativo se marcado
        confirmar = st.checkbox("Confirmo que desejo excluir este cliente.")

        # disabled=not confirmar: desativa o botão enquanto o checkbox não for marcado
        if st.button("🗑️ Excluir Cliente", type="primary", disabled=not confirmar, use_container_width=True):
            sucesso = crud_db.delete(NOME_TABELA, {"id": cliente_sel["id"]})
            if sucesso:
                st.success(f"✅ Cliente **{cliente_sel['nome']}** excluído com sucesso!")
                st.rerun()  # Atualiza a lista após a exclusão
            else:
                st.error("❌ Erro ao excluir cliente. Verifique o log.")
