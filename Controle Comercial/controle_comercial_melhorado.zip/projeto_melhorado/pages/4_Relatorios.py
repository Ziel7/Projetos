# /////////////////////////////////////////////////////
# // Instituição  : SENAI
# // Disciplina   : Projeto Integrador
# // Nome Projeto : Controle Comercial
# // Aluno        : Gabriel Florentino
# // Data Atual   : 29/04/2026
# /////////////////////////////////////////////////////

"""
pages/4_Relatorios.py - Tela de relatórios e análises
Exibe métricas gerais e relatórios detalhados de vendas, produtos,
clientes e situação do estoque, com opção de exportar para CSV.
"""

# ─── IMPORTAÇÃO DAS BIBLIOTECAS ────────────────────────────────────────────────
import streamlit as st    # Streamlit: interface web
import sys                # sys: configuração do caminho de importação
import os                 # os: acesso ao sistema operacional
from pathlib import Path  # Path: manipulação de caminhos
import pandas as pd       # pandas: análise e manipulação de dados tabulares

# Adiciona a pasta raiz ao path para importar crud_db
sys.path.insert(0, str(Path(__file__).parent.parent))
import crud_db  # Funções de banco de dados

# ─── CONSTANTES ───────────────────────────────────────────────────────────────
LIMITE_ESTOQUE = 5  # Limiar de estoque para alerta visual (igual ao de Produtos)

# ─── CONFIGURAÇÃO DA PÁGINA ───────────────────────────────────────────────────
st.set_page_config(
    page_title="Relatórios | Controle Comercial",
    page_icon="📈",
    layout="wide"
)

# ─── CABEÇALHO ────────────────────────────────────────────────────────────────
st.markdown("# 📈 Relatórios")
st.markdown("Análises e visões gerais do negócio.")
st.divider()

# ─── CARREGAMENTO DOS DADOS ───────────────────────────────────────────────────
# Busca todos os dados necessários para os relatórios de uma vez
vendas_raw   = crud_db.select_vendas_completo()  # Vendas com JOIN de clientes e produtos
clientes_raw = crud_db.select("clientes")        # Todos os clientes
produtos_raw = crud_db.select("produtos")        # Todos os produtos

# ─── MÉTRICAS GERAIS ──────────────────────────────────────────────────────────
st.markdown("### 📊 Resumo Geral")

# Calcula as métricas principais a partir dos dados carregados
total_vendas   = len(vendas_raw)                                        # Contagem total de vendas
faturamento    = sum(v["total"] for v in vendas_raw) if vendas_raw else 0  # Soma de todos os totais

# Ticket médio = faturamento total / número de vendas (evita divisão por zero)
ticket_medio   = faturamento / total_vendas if total_vendas > 0 else 0

total_clientes = len(clientes_raw)   # Número de clientes cadastrados
total_produtos = len(produtos_raw)   # Número de produtos cadastrados

# Exibe as 5 métricas em colunas lado a lado
m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("💰 Faturamento Total", f"R$ {faturamento:,.2f}")   # :,.2f = separador de milhar e 2 decimais
m2.metric("🛒 Total de Vendas",   total_vendas)
m3.metric("🎯 Ticket Médio",      f"R$ {ticket_medio:,.2f}")
m4.metric("👥 Clientes",          total_clientes)
m5.metric("📦 Produtos",          total_produtos)

st.divider()

# ─── ABAS DE RELATÓRIOS ───────────────────────────────────────────────────────
aba_vendas, aba_produtos, aba_clientes, aba_estoque = st.tabs([
    "📋 Vendas", "📦 Produtos Mais Vendidos", "👤 Clientes", "📊 Estoque"
])

# ════════════════════════════════════════════════════════════════════════════════
# ABA: RELATÓRIO DE VENDAS
# ════════════════════════════════════════════════════════════════════════════════
with aba_vendas:
    st.subheader("Relatório de Vendas")

    if not vendas_raw:
        st.info("Nenhuma venda registrada ainda.")
    else:
        # Filtros de busca: cliente, produto e data
        col1, col2, col3 = st.columns(3)
        with col1:
            filtro_cliente = st.text_input("🔍 Filtrar por cliente", key="rel_cliente")
        with col2:
            filtro_produto = st.text_input("🔍 Filtrar por produto", key="rel_produto")
        with col3:
            filtro_data = st.text_input("📅 Filtrar por data (AAAA-MM-DD)", placeholder="Ex: 2026-04")

        # Re-consulta com filtros de cliente e produto aplicados no banco
        vendas_filtradas = crud_db.select_vendas_completo(filtro_cliente, filtro_produto)

        df = pd.DataFrame(vendas_filtradas)
        if not df.empty:
            df.columns = ["ID", "Cliente", "Produto", "Qtd", "Total", "Data"]

            # Filtro de data aplicado no pandas (após o banco)
            # str.startswith() verifica se a data começa com o texto digitado
            if filtro_data:
                df = df[df["Data"].str.startswith(filtro_data)]

            # Cópia formatada para exibição (não altera os valores numéricos originais)
            df_exib = df.copy()
            df_exib["Total"] = df_exib["Total"].apply(lambda x: f"R$ {x:,.2f}")

            st.dataframe(df_exib, use_container_width=True, hide_index=True)

            # Total filtrado: soma os valores numéricos da coluna Total do DataFrame original
            total_filtrado = df["Total"].sum()
            st.info(f"💰 Total filtrado: **R$ {total_filtrado:,.2f}** em **{len(df)}** venda(s)")

            # Exportação para CSV usando pandas to_csv() e st.download_button
            csv = df_exib.to_csv(index=False).encode("utf-8")  # Gera o CSV em memória
            st.download_button(
                label="⬇️ Exportar para CSV",
                data=csv,
                file_name="relatorio_vendas.csv",  # Nome do arquivo para download
                mime="text/csv",                    # Tipo MIME para o navegador reconhecer
            )
        else:
            st.info("Nenhuma venda encontrada com os filtros aplicados.")

# ════════════════════════════════════════════════════════════════════════════════
# ABA: PRODUTOS MAIS VENDIDOS
# ════════════════════════════════════════════════════════════════════════════════
with aba_produtos:
    st.subheader("Produtos Mais Vendidos")

    if not vendas_raw:
        st.info("Nenhuma venda registrada ainda.")
    else:
        df = pd.DataFrame(vendas_raw)
        df.columns = ["id", "cliente", "produto", "qtd", "total", "data"]

        # groupby("produto"): agrupa todas as linhas pelo nome do produto
        # .agg(): calcula métricas para cada grupo (soma, contagem)
        ranking = (
            df.groupby("produto")
            .agg(
                qtd_total  =("qtd",   "sum"),    # Soma das quantidades vendidas
                faturamento=("total", "sum"),    # Soma do faturamento gerado
                num_vendas =("id",    "count")   # Contagem de transações
            )
            .sort_values("faturamento", ascending=False)  # Ordena do maior faturamento
            .reset_index()  # Transforma o índice agrupado de volta em coluna
        )
        ranking.columns = ["Produto", "Qtd Vendida", "Faturamento (R$)", "Nº Vendas"]
        ranking["Faturamento (R$)"] = ranking["Faturamento (R$)"].apply(lambda x: f"R$ {x:,.2f}")
        ranking.index = ranking.index + 1  # Ranking começa em 1 (posição no pódio)

        st.dataframe(ranking, use_container_width=True)

        # Gráfico de barras nativo do Streamlit
        df_chart = df.groupby("produto")["total"].sum().sort_values(ascending=False)
        st.markdown("##### Faturamento por Produto")
        st.bar_chart(df_chart)  # st.bar_chart cria gráfico de barras simples automaticamente

# ════════════════════════════════════════════════════════════════════════════════
# ABA: CLIENTES QUE MAIS COMPRARAM
# ════════════════════════════════════════════════════════════════════════════════
with aba_clientes:
    st.subheader("Clientes que Mais Compraram")

    if not vendas_raw:
        st.info("Nenhuma venda registrada ainda.")
    else:
        df = pd.DataFrame(vendas_raw)
        df.columns = ["id", "cliente", "produto", "qtd", "total", "data"]

        # Agrupa por cliente e calcula total gasto e número de compras
        ranking_clientes = (
            df.groupby("cliente")
            .agg(
                total_gasto =("total", "sum"),    # Total gasto pelo cliente
                num_compras =("id",    "count")   # Número de compras realizadas
            )
            .sort_values("total_gasto", ascending=False)
            .reset_index()
        )
        ranking_clientes.columns = ["Cliente", "Total Gasto (R$)", "Nº Compras"]
        ranking_clientes["Total Gasto (R$)"] = ranking_clientes["Total Gasto (R$)"].apply(
            lambda x: f"R$ {x:,.2f}"
        )
        ranking_clientes.index = ranking_clientes.index + 1

        st.dataframe(ranking_clientes, use_container_width=True)

        df_chart_cli = df.groupby("cliente")["total"].sum().sort_values(ascending=False)
        st.markdown("##### Gastos por Cliente")
        st.bar_chart(df_chart_cli)

# ════════════════════════════════════════════════════════════════════════════════
# ABA: SITUAÇÃO DO ESTOQUE
# ════════════════════════════════════════════════════════════════════════════════
with aba_estoque:
    st.subheader("Situação do Estoque")

    if not produtos_raw:
        st.info("Nenhum produto cadastrado ainda.")
    else:
        df_est = pd.DataFrame(produtos_raw)
        df_est.columns = ["ID", "Produto", "Preço (R$)", "Estoque"]

        # Classifica cada produto por status de estoque usando a constante LIMITE_ESTOQUE
        df_est["Status"] = df_est["Estoque"].apply(
            lambda x: "🔴 Zerado" if x == 0 else ("🟡 Crítico (≤5)" if x <= LIMITE_ESTOQUE else "🟢 Normal")
        )
        df_est["Preço (R$)"] = df_est["Preço (R$)"].apply(lambda x: f"R$ {x:,.2f}")

        # Calcula o valor financeiro total em estoque para cada produto (preço × quantidade)
        df_est["Valor em Estoque"] = [
            f"R$ {p['preco'] * p['estoque']:,.2f}" for p in produtos_raw
        ]

        # Multiselect: permite filtrar a tabela por um ou mais status
        status_filtro = st.multiselect(
            "Filtrar por status:",
            ["🔴 Zerado", "🟡 Crítico (≤5)", "🟢 Normal"],
            default=["🔴 Zerado", "🟡 Crítico (≤5)", "🟢 Normal"]  # Todos selecionados por padrão
        )

        # Filtra o DataFrame para exibir apenas os status selecionados
        df_filtrado = df_est[df_est["Status"].isin(status_filtro)]
        st.dataframe(df_filtrado, use_container_width=True, hide_index=True)

        # Calcula e exibe o valor total em estoque (indicador financeiro)
        valor_total_estoque = sum(p["preco"] * p["estoque"] for p in produtos_raw)
        st.success(f"💰 Valor total em estoque: **R$ {valor_total_estoque:,.2f}**")

        # Gráfico de barras com quantidade em estoque por produto
        df_chart_est = pd.Series({p["nome"]: p["estoque"] for p in produtos_raw}).sort_values(ascending=False)
        st.markdown("##### Quantidade em Estoque por Produto")
        st.bar_chart(df_chart_est)
