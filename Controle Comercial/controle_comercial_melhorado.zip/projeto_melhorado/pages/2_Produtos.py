# /////////////////////////////////////////////////////
# // Instituição  : SENAI
# // Disciplina   : Projeto Integrador
# // Nome Projeto : Controle Comercial
# // Aluno        : Gabriel Florentino
# // Data Atual   : 29/04/2026
# /////////////////////////////////////////////////////

"""
pages/2_Produtos.py - Tela de gerenciamento de produtos
Permite cadastrar, listar, editar, ajustar estoque e excluir produtos.
"""

# ─── IMPORTAÇÃO DAS BIBLIOTECAS ────────────────────────────────────────────────
import streamlit as st    # Streamlit: interface web
import sys                # sys: configuração do caminho de importação
import os                 # os: acesso ao sistema operacional
from pathlib import Path  # Path: manipulação de caminhos

# Adiciona a pasta raiz ao path para encontrar o módulo crud_db
sys.path.insert(0, str(Path(__file__).parent.parent))
import crud_db  # Módulo com as funções de banco de dados

# ─── CONSTANTES ───────────────────────────────────────────────────────────────
NOME_TABELA      = "produtos"  # Tabela gerenciada por esta página
LIMITE_ESTOQUE   = 5           # Quantidade mínima antes de emitir alerta de estoque baixo

# ─── CONFIGURAÇÃO DA PÁGINA ───────────────────────────────────────────────────
st.set_page_config(
    page_title="Produtos | Controle Comercial",
    page_icon="📦",
    layout="wide"
)

# ─── CABEÇALHO ────────────────────────────────────────────────────────────────
st.markdown("# 📦 Produtos")
st.markdown("Gerencie o catálogo de produtos e controle de estoque.")
st.divider()

# ─── ABAS ─────────────────────────────────────────────────────────────────────
aba_cadastrar, aba_listar, aba_editar, aba_estoque, aba_excluir = st.tabs([
    "➕ Cadastrar", "📋 Listar", "✏️ Editar", "📊 Estoque", "🗑️ Excluir"
])

# ════════════════════════════════════════════════════════════════════════════════
# ABA: CADASTRAR
# ════════════════════════════════════════════════════════════════════════════════
with aba_cadastrar:
    st.subheader("Novo Produto")

    # Três colunas iguais para os campos do formulário
    col1, col2, col3 = st.columns(3)
    with col1:
        nome = st.text_input("Nome do Produto *", placeholder="Ex: Camisa Polo")
    with col2:
        # number_input cria campo numérico com valor mínimo, incremento e formatação
        preco = st.number_input("Preço (R$) *", min_value=0.0, step=0.01, format="%.2f")
    with col3:
        estoque = st.number_input("Estoque Inicial *", min_value=0, step=1)

    if st.button("💾 Salvar Produto", type="primary", use_container_width=True):
        if not nome.strip():
            st.error("O campo **Nome** é obrigatório.")
        elif preco <= 0:
            st.error("O **Preço** deve ser maior que zero.")
        else:
            # Insere o produto no banco via função insert() do crud_db
            novo_id = crud_db.insert(NOME_TABELA, {
                "nome":    nome.strip(),
                "preco":   preco,
                "estoque": estoque,
            })
            if novo_id:
                st.success(f"✅ Produto **{nome}** cadastrado com sucesso! (ID: {novo_id})")
                st.balloons()
            else:
                st.error("❌ Erro ao cadastrar produto. Verifique o log.")

# ════════════════════════════════════════════════════════════════════════════════
# ABA: LISTAR
# ════════════════════════════════════════════════════════════════════════════════
with aba_listar:
    st.subheader("Catálogo de Produtos")

    produtos = crud_db.select(NOME_TABELA)  # Busca todos os produtos

    if not produtos:
        st.info("Nenhum produto cadastrado ainda.")
    else:
        import pandas as pd
        df = pd.DataFrame(produtos)
        df.columns = ["ID", "Nome", "Preço (R$)", "Estoque"]

        # Formata os preços com "R$" e 2 casas decimais para melhor legibilidade
        df["Preço (R$)"] = df["Preço (R$)"].apply(lambda x: f"R$ {x:,.2f}")

        # Campo de busca por nome
        busca = st.text_input("🔍 Buscar por nome", placeholder="Digite parte do nome...")
        if busca:
            df = df[df["Nome"].str.contains(busca, case=False, na=False)]

        # Alerta se algum produto tiver estoque abaixo do limite definido na constante
        produtos_baixos = [p for p in produtos if p["estoque"] <= LIMITE_ESTOQUE]
        if produtos_baixos:
            st.warning(f"⚠️ {len(produtos_baixos)} produto(s) com estoque ≤ {LIMITE_ESTOQUE} unidades!")

        st.dataframe(df, use_container_width=True, hide_index=True)
        st.caption(f"Total: {len(df)} produto(s)")

# ════════════════════════════════════════════════════════════════════════════════
# ABA: EDITAR
# ════════════════════════════════════════════════════════════════════════════════
with aba_editar:
    st.subheader("Editar Produto")

    produtos = crud_db.select(NOME_TABELA)

    if not produtos:
        st.info("Nenhum produto cadastrado ainda.")
    else:
        opcoes = {f"[{p['id']}] {p['nome']}": p for p in produtos}
        selecionado_label = st.selectbox("Selecione o produto para editar:", list(opcoes.keys()))
        produto_sel = opcoes[selecionado_label]  # Produto atualmente selecionado

        col1, col2, col3 = st.columns(3)
        with col1:
            novo_nome = st.text_input("Nome *", value=produto_sel["nome"])
        with col2:
            # float() converte o valor do banco para o tipo esperado pelo number_input
            novo_preco = st.number_input("Preço (R$) *", value=float(produto_sel["preco"]),
                                         min_value=0.0, step=0.01, format="%.2f")
        with col3:
            # int() garante que o estoque seja inteiro
            novo_estoque = st.number_input("Estoque *", value=int(produto_sel["estoque"]),
                                            min_value=0, step=1)

        if st.button("💾 Atualizar Produto", type="primary", use_container_width=True):
            if not novo_nome.strip():
                st.error("O campo **Nome** é obrigatório.")
            else:
                sucesso = crud_db.update(
                    NOME_TABELA,
                    dados={"nome": novo_nome.strip(), "preco": novo_preco, "estoque": novo_estoque},
                    condicoes={"id": produto_sel["id"]}
                )
                if sucesso:
                    st.success(f"✅ Produto **{novo_nome}** atualizado com sucesso!")
                    st.rerun()
                else:
                    st.error("❌ Erro ao atualizar produto. Verifique o log.")

# ════════════════════════════════════════════════════════════════════════════════
# ABA: CONTROLE DE ESTOQUE
# ════════════════════════════════════════════════════════════════════════════════
with aba_estoque:
    st.subheader("Ajuste Rápido de Estoque")

    produtos = crud_db.select(NOME_TABELA)

    if not produtos:
        st.info("Nenhum produto cadastrado ainda.")
    else:
        import pandas as pd

        # Label do selectbox mostra o estoque atual para facilitar a escolha
        opcoes = {f"[{p['id']}] {p['nome']} — Estoque: {p['estoque']}": p for p in produtos}
        selecionado_label = st.selectbox("Selecione o produto:", list(opcoes.keys()), key="estoque_sel")
        produto_sel = opcoes[selecionado_label]

        # Exibe o estoque atual em destaque com st.metric
        st.metric("Estoque Atual", produto_sel["estoque"])

        col1, col2 = st.columns(2)
        with col1:
            # Radio button para escolher o tipo de ajuste
            tipo_ajuste = st.radio("Tipo de Ajuste:", ["➕ Entrada", "➖ Saída", "🔄 Definir valor"])
        with col2:
            quantidade = st.number_input("Quantidade:", min_value=1, step=1, value=1)

        if st.button("📊 Aplicar Ajuste", type="primary", use_container_width=True):
            estoque_atual = produto_sel["estoque"]  # Estoque antes do ajuste

            # Calcula o novo estoque de acordo com o tipo de ajuste escolhido
            if tipo_ajuste == "➕ Entrada":
                novo_estoque = estoque_atual + quantidade          # Adiciona ao estoque
            elif tipo_ajuste == "➖ Saída":
                novo_estoque = max(0, estoque_atual - quantidade)  # Subtrai, mínimo 0
            else:
                novo_estoque = quantidade                          # Define valor fixo

            sucesso = crud_db.update(
                NOME_TABELA,
                dados={"estoque": novo_estoque},
                condicoes={"id": produto_sel["id"]}
            )
            if sucesso:
                st.success(f"✅ Estoque ajustado: {estoque_atual} → {novo_estoque}")
                st.rerun()
            else:
                st.error("❌ Erro ao ajustar estoque. Verifique o log.")

        # Tabela resumo mostrando o status de todos os produtos
        st.divider()
        st.markdown("#### 📊 Visão Geral do Estoque")
        df = pd.DataFrame(produtos)[["id", "nome", "estoque"]]
        df.columns = ["ID", "Produto", "Estoque"]

        # Função lambda aplica uma lógica para cada valor de estoque e retorna o status
        df["Status"] = df["Estoque"].apply(
            lambda x: "🔴 Crítico" if x == 0 else ("🟡 Baixo" if x <= LIMITE_ESTOQUE else "🟢 OK")
        )
        st.dataframe(df, use_container_width=True, hide_index=True)

# ════════════════════════════════════════════════════════════════════════════════
# ABA: EXCLUIR
# ════════════════════════════════════════════════════════════════════════════════
with aba_excluir:
    st.subheader("Excluir Produto")

    produtos = crud_db.select(NOME_TABELA)

    if not produtos:
        st.info("Nenhum produto cadastrado ainda.")
    else:
        opcoes = {f"[{p['id']}] {p['nome']}": p for p in produtos}
        selecionado_label = st.selectbox(
            "Selecione o produto para excluir:",
            list(opcoes.keys()),
            key="excluir_prod"  # Chave única para diferenciar dos outros selectboxes
        )
        produto_sel = opcoes[selecionado_label]

        st.warning(f"⚠️ Você está prestes a excluir: **{produto_sel['nome']}**")
        confirmar = st.checkbox("Confirmo que desejo excluir este produto.")

        if st.button("🗑️ Excluir Produto", type="primary", disabled=not confirmar, use_container_width=True):
            sucesso = crud_db.delete(NOME_TABELA, {"id": produto_sel["id"]})
            if sucesso:
                st.success(f"✅ Produto **{produto_sel['nome']}** excluído!")
                st.rerun()
            else:
                st.error("❌ Erro ao excluir produto. Verifique o log.")
