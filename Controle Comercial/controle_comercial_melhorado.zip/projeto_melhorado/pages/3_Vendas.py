# /////////////////////////////////////////////////////
# // Instituição  : SENAI
# // Disciplina   : Projeto Integrador
# // Nome Projeto : Controle Comercial
# // Aluno        : Gabriel Florentino
# // Data Atual   : 29/04/2026
# /////////////////////////////////////////////////////

"""
pages/3_Vendas.py - Tela de registro de vendas
Permite registrar novas vendas, consultar o histórico e cancelar vendas.
Ao confirmar uma venda, o estoque do produto é descontado automaticamente.
"""

# ─── IMPORTAÇÃO DAS BIBLIOTECAS ────────────────────────────────────────────────
import streamlit as st           # Streamlit: interface web
import sys                       # sys: configuração do caminho de importação
import os                        # os: acesso ao sistema operacional
from pathlib import Path         # Path: caminhos de arquivos
from datetime import datetime    # datetime: gera a data e hora atual da venda

# Adiciona a pasta raiz ao path para importar crud_db
sys.path.insert(0, str(Path(__file__).parent.parent))
import crud_db  # Funções de banco de dados

# ─── CONSTANTES ───────────────────────────────────────────────────────────────
FORMATO_DATA = "%Y-%m-%d %H:%M:%S"  # Formato padrão de data e hora usado no banco

# ─── CONFIGURAÇÃO DA PÁGINA ───────────────────────────────────────────────────
st.set_page_config(
    page_title="Vendas | Controle Comercial",
    page_icon="💰",
    layout="wide"
)

# ─── CABEÇALHO ────────────────────────────────────────────────────────────────
st.markdown("# 💰 Vendas")
st.markdown("Registre novas vendas e consulte o histórico.")
st.divider()

# ─── ABAS ─────────────────────────────────────────────────────────────────────
aba_nova, aba_historico, aba_excluir = st.tabs([
    "➕ Nova Venda", "📋 Histórico", "🗑️ Cancelar Venda"
])

# ════════════════════════════════════════════════════════════════════════════════
# ABA: NOVA VENDA
# ════════════════════════════════════════════════════════════════════════════════
with aba_nova:
    st.subheader("Registrar Nova Venda")

    # Carrega clientes e produtos do banco para os selectboxes
    clientes = crud_db.select("clientes")
    produtos  = crud_db.select("produtos")

    # Se não houver clientes ou produtos, avisa e interrompe a renderização desta aba
    if not clientes:
        st.warning("⚠️ Nenhum cliente cadastrado. Vá em **Clientes** para cadastrar.")
        st.stop()
    if not produtos:
        st.warning("⚠️ Nenhum produto cadastrado. Vá em **Produtos** para cadastrar.")
        st.stop()

    col1, col2 = st.columns(2)

    with col1:
        # Dicionário de clientes: label exibido no selectbox → objeto do cliente
        opcoes_clientes = {f"[{c['id']}] {c['nome']}": c for c in clientes}
        cliente_label = st.selectbox("👤 Cliente *", list(opcoes_clientes.keys()))
        cliente_sel   = opcoes_clientes[cliente_label]  # Cliente selecionado

    with col2:
        # Label do produto inclui estoque e preço para ajudar na escolha
        opcoes_produtos = {
            f"[{p['id']}] {p['nome']} — Estoque: {p['estoque']} — R$ {p['preco']:.2f}": p
            for p in produtos
        }
        produto_label = st.selectbox("📦 Produto *", list(opcoes_produtos.keys()))
        produto_sel   = opcoes_produtos[produto_label]  # Produto selecionado

    # Exibe informações do produto selecionado em métricas visuais
    col3, col4, col5 = st.columns(3)
    with col3:
        preco_unitario = produto_sel["preco"]           # Preço do produto selecionado
        st.metric("💵 Preço Unitário", f"R$ {preco_unitario:.2f}")
    with col4:
        estoque_disponivel = produto_sel["estoque"]     # Estoque atual do produto
        st.metric("📦 Estoque Disponível", estoque_disponivel)
    with col5:
        # max_value limita a quantidade ao estoque disponível
        quantidade = st.number_input(
            "Quantidade *",
            min_value=1,
            max_value=max(1, estoque_disponivel),  # Evita max_value < min_value
            step=1,
            value=1
        )

    # Calcula o total da venda: preço unitário × quantidade
    total = preco_unitario * quantidade

    # Exibe o total em um card colorido destacado
    st.markdown(f"""
    <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white; padding: 20px; border-radius: 12px; text-align: center; margin: 10px 0;'>
        <h3 style='margin:0; color:white;'>💳 Total da Venda</h3>
        <h1 style='margin:5px 0; color:white;'>R$ {total:,.2f}</h1>
        <p style='margin:0; opacity:0.8;'>{quantidade} × R$ {preco_unitario:.2f}</p>
    </div>
    """, unsafe_allow_html=True)

    # datetime.now().strftime() formata a data/hora atual como string
    data_venda = datetime.now().strftime(FORMATO_DATA)

    if st.button("✅ Confirmar Venda", type="primary", use_container_width=True):
        if estoque_disponivel < quantidade:
            # Verifica novamente o estoque antes de registrar (segurança extra)
            st.error(f"❌ Estoque insuficiente! Disponível: {estoque_disponivel}")
        else:
            # 1. Registra a venda no banco com todos os dados
            novo_id = crud_db.insert("vendas", {
                "cliente_id": cliente_sel["id"],   # ID do cliente selecionado
                "produto_id": produto_sel["id"],   # ID do produto selecionado
                "qtd":        quantidade,           # Quantidade vendida
                "total":      total,               # Valor total calculado
                "data":       data_venda,          # Data/hora da venda
            })

            if novo_id:
                # 2. Desconta a quantidade vendida do estoque do produto
                novo_estoque = estoque_disponivel - quantidade
                crud_db.update(
                    "produtos",
                    dados={"estoque": novo_estoque},
                    condicoes={"id": produto_sel["id"]}
                )
                st.success(f"✅ Venda **#{novo_id}** registrada com sucesso!")
                st.info(f"📦 Estoque de **{produto_sel['nome']}**: {estoque_disponivel} → {novo_estoque}")
                st.balloons()
            else:
                st.error("❌ Erro ao registrar venda. Verifique o log.")

# ════════════════════════════════════════════════════════════════════════════════
# ABA: HISTÓRICO DE VENDAS
# ════════════════════════════════════════════════════════════════════════════════
with aba_historico:
    st.subheader("Histórico de Vendas")

    # select_vendas_completo faz JOIN com clientes e produtos para trazer nomes
    vendas = crud_db.select_vendas_completo()

    if not vendas:
        st.info("Nenhuma venda registrada ainda.")
    else:
        import pandas as pd
        df = pd.DataFrame(vendas)
        df.columns = ["ID", "Cliente", "Produto", "Qtd", "Total (R$)", "Data"]

        # Formata a coluna de total com símbolo de moeda
        df["Total (R$)"] = df["Total (R$)"].apply(lambda x: f"R$ {x:,.2f}")

        # Filtros de busca por cliente e produto
        col1, col2 = st.columns(2)
        with col1:
            filtro_cliente = st.text_input("🔍 Filtrar por cliente")
        with col2:
            filtro_produto = st.text_input("🔍 Filtrar por produto")

        # Re-consulta o banco com os filtros aplicados (se houver)
        if filtro_cliente or filtro_produto:
            vendas_filtradas = crud_db.select_vendas_completo(filtro_cliente, filtro_produto)
            df = pd.DataFrame(vendas_filtradas)
            if not df.empty:
                df.columns = ["ID", "Cliente", "Produto", "Qtd", "Total (R$)", "Data"]
                df["Total (R$)"] = df["Total (R$)"].apply(lambda x: f"R$ {x:,.2f}")

        # Métricas rápidas: total de vendas e faturamento com os filtros aplicados
        vendas_raw = crud_db.select_vendas_completo(filtro_cliente, filtro_produto)
        if vendas_raw:
            # sum() soma todos os valores de "total" da lista de dicionários
            total_fat = sum(v["total"] for v in vendas_raw)
            col_m1, col_m2 = st.columns(2)
            col_m1.metric("Total de Vendas no Filtro", len(vendas_raw))
            col_m2.metric("Faturamento no Filtro", f"R$ {total_fat:,.2f}")

        st.dataframe(df, use_container_width=True, hide_index=True)

# ════════════════════════════════════════════════════════════════════════════════
# ABA: CANCELAR VENDA
# ════════════════════════════════════════════════════════════════════════════════
with aba_excluir:
    st.subheader("Cancelar Venda")

    vendas = crud_db.select_vendas_completo()

    if not vendas:
        st.info("Nenhuma venda registrada ainda.")
    else:
        # Label descritivo: mostra ID, cliente, produto, valor e data resumida
        opcoes = {
            f"[#{v['id']}] {v['cliente']} — {v['produto']} — R$ {v['total']:.2f} ({v['data'][:10]})": v
            for v in vendas
        }
        selecionado_label = st.selectbox("Selecione a venda para cancelar:", list(opcoes.keys()))
        venda_sel = opcoes[selecionado_label]

        st.warning("⚠️ Ao cancelar, o estoque do produto será **restaurado**.")
        confirmar = st.checkbox("Confirmo o cancelamento desta venda.")

        if st.button("🗑️ Cancelar Venda", type="primary", disabled=not confirmar, use_container_width=True):
            sucesso = crud_db.delete("vendas", {"id": venda_sel["id"]})
            if sucesso:
                st.success(f"✅ Venda **#{venda_sel['id']}** cancelada com sucesso!")
                st.rerun()
            else:
                st.error("❌ Erro ao cancelar venda. Verifique o log.")
