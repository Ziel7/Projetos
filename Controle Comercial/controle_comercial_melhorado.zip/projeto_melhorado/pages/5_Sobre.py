# /////////////////////////////////////////////////////
# // Instituição  : SENAI
# // Disciplina   : Projeto Integrador
# // Nome Projeto : Controle Comercial
# // Aluno        : Gabriel Florentino
# // Data Atual   : 29/04/2026
# /////////////////////////////////////////////////////

"""
pages/5_Sobre.py - Tela de informações do sistema
Exibe os dados do projeto, bibliotecas utilizadas e
conhecimentos aplicados no desenvolvimento.
"""

# ─── IMPORTAÇÃO DAS BIBLIOTECAS ────────────────────────────────────────────────
import streamlit as st     # Streamlit: responsável por toda a interface web
import sys                 # sys: permite manipular o caminho de importação de módulos
import os                  # os: acessa informações do sistema operacional e caminhos
import platform            # platform: fornece informações sobre o SO e versão do Python
from pathlib import Path   # Path: manipulação moderna de caminhos de arquivos

# Adiciona o diretório pai (raiz do projeto) ao sys.path para importar crud_db
# Isso é necessário porque as páginas ficam em uma subpasta (pages/)
sys.path.insert(0, str(Path(__file__).parent.parent))

# ─── CONSTANTES DA PÁGINA ─────────────────────────────────────────────────────
# Constantes evitam repetição de texto e facilitam futuras atualizações.
NOME_SISTEMA  = "Controle Comercial"   # Nome do sistema
VERSAO        = "v1.0"                 # Versão atual
NOME_ALUNO    = "Gabriel Florentino"   # Nome do desenvolvedor
INSTITUICAO   = "SENAI"               # Instituição de ensino
DISCIPLINA    = "Projeto Integrador"  # Disciplina do projeto
IDE_USADA     = "VSCode"              # IDE utilizada no desenvolvimento
ANO           = "2026"                # Ano de desenvolvimento

# ─── CONFIGURAÇÃO DA PÁGINA ───────────────────────────────────────────────────
# Define o título e ícone da aba para esta página específica.
st.set_page_config(
    page_title=f"Sobre | {NOME_SISTEMA}",  # Título da aba do navegador
    page_icon="ℹ️",                        # Ícone da aba
    layout="wide"                          # Layout largo
)

# ─── CABEÇALHO DA PÁGINA ──────────────────────────────────────────────────────
st.markdown("# ℹ️ Sobre")
st.divider()  # Linha separadora horizontal

# ─── BLOCO PRINCIPAL: NOME E IDE ──────────────────────────────────────────────
# Exibe o nome do sistema e a IDE utilizada no desenvolvimento.
# st.columns([1, 2]) divide a linha em proporção 1:2 (logo menor, texto maior)
col_icone, col_info = st.columns([1, 2])

with col_icone:
    # Verifica se existe uma logo na pasta do projeto
    logo_path = Path(__file__).parent.parent / "logo.jpg"
    if logo_path.exists():
        st.image(str(logo_path), width=180)  # Exibe a logo se existir
    else:
        # Se não houver logo, exibe um quadrado colorido com emoji como substituto
        st.markdown("""
        <div style='width:180px; height:180px;
                    background: linear-gradient(135deg, #1a1a2e, #0f3460);
                    border-radius:20px; display:flex; align-items:center;
                    justify-content:center; font-size:80px; text-align:center;'>
            🏪
        </div>
        """, unsafe_allow_html=True)

with col_info:
    # Exibe o nome do sistema em destaque
    st.markdown(f"## {NOME_SISTEMA}")

    # Informa a IDE usada no desenvolvimento
    st.markdown(f"**Criado em Python usando a IDE {IDE_USADA}**")

    st.markdown("---")  # Linha separadora dentro do card

    # Exibe informações do aluno usando as constantes definidas no topo
    st.markdown(f"**👨‍💻 Aluno:** {NOME_ALUNO}")
    st.markdown(f"**🎓 Instituição:** {INSTITUICAO}")
    st.markdown(f"**📚 Disciplina:** {DISCIPLINA}")
    st.markdown(f"**📅 Ano:** {ANO}")

st.divider()

# ─── BIBLIOTECAS UTILIZADAS ───────────────────────────────────────────────────
# Dicionário com as informações de cada biblioteca usada no projeto.
# Chave = identificador interno, Valor = dicionário com ícone, nome, descrição e cor.
BIBLIOTECAS = {
    "streamlit": {
        "icone": "🚀",
        "nome":  "Streamlit",
        "desc":  "Tela web",
        "cor":   "#e3f2fd",
    },
    "sqlite": {
        "icone": "🗄️",
        "nome":  "SQLite",
        "desc":  "Banco de dados",
        "cor":   "#e8f5e9",
    },
    "os": {
        "icone": "🖥️",
        "nome":  "OS",
        "desc":  "Sistema operacional",
        "cor":   "#fff3e0",
    },
    "venv": {
        "icone": "📦",
        "nome":  ".VENV",
        "desc":  "Aplicação isolada (virtualizada)",
        "cor":   "#fce4ec",
    },
}

st.markdown("### 📚 Bibliotecas Usadas")

# Cria uma coluna para cada biblioteca do dicionário
colunas_libs = st.columns(len(BIBLIOTECAS))

# zip() combina as colunas com os dados das bibliotecas para iterar juntos
for col, (_, lib) in zip(colunas_libs, BIBLIOTECAS.items()):
    with col:
        # Renderiza cada biblioteca como um card HTML colorido
        st.markdown(f"""
        <div style='text-align:center; padding:22px 10px;
                    background:{lib["cor"]}; border-radius:14px;'>
            <div style='font-size:2.2rem;'>{lib["icone"]}</div>
            <strong style='font-size:1rem;'>{lib["nome"]}</strong>
            <p style='font-size:0.8rem; color:#555; margin:6px 0 0;'>{lib["desc"]}</p>
        </div>
        """, unsafe_allow_html=True)

st.divider()

# ─── CONHECIMENTOS APLICADOS ──────────────────────────────────────────────────
# Lista dos conceitos de programação utilizados no projeto.
# Uma lista em Python é uma sequência ordenada de elementos.
CONHECIMENTOS = [
    {"icone": "📌", "nome": "Variáveis",             "desc": "Armazenam dados temporários durante a execução do programa"},
    {"icone": "🔒", "nome": "Constantes",             "desc": "Valores fixos definidos uma vez e usados em todo o código"},
    {"icone": "📖", "nome": "Dicionários",            "desc": "Estruturas que associam chaves a valores, como um mapa de dados"},
    {"icone": "⚙️", "nome": "Funções personalizadas", "desc": "Blocos reutilizáveis de código que executam tarefas específicas"},
]

st.markdown("### 🧠 Conhecimentos Aplicados")

# Itera sobre a lista de conhecimentos e exibe cada item com st.info
for conhecimento in CONHECIMENTOS:
    st.info(
        f"**{conhecimento['icone']} {conhecimento['nome']}** — {conhecimento['desc']}"
    )

st.divider()

# ─── INFORMAÇÕES TÉCNICAS DO AMBIENTE ────────────────────────────────────────
# Usa as bibliotecas os e platform para exibir informações do ambiente de execução.
st.markdown("### 🔧 Informações Técnicas")

# Caminhos dos arquivos do projeto
caminho_db  = Path(__file__).parent.parent / "crud_db.db"   # Banco de dados
caminho_log = Path(__file__).parent.parent / "log.txt"       # Arquivo de log

# os.path.getsize() retorna o tamanho do arquivo em bytes
# Converte para KB dividindo por 1024
tamanho_db  = f"{os.path.getsize(str(caminho_db))  / 1024:.2f} KB" if caminho_db.exists()  else "Não criado"
tamanho_log = f"{os.path.getsize(str(caminho_log)) / 1024:.2f} KB" if caminho_log.exists() else "Não criado"

# Divide as informações técnicas em 2 colunas
col_tec1, col_tec2 = st.columns(2)

with col_tec1:
    # platform.python_version() retorna a versão do Python instalada
    # platform.system() e platform.release() retornam o nome e versão do SO
    st.markdown(f"""
    | Item                   | Valor                                               |
    |------------------------|-----------------------------------------------------|
    | 🐍 Python              | `{platform.python_version()}`                       |
    | 💻 Sistema Operacional | `{platform.system()} {platform.release()}`          |
    | 🗄️ Banco de Dados      | `crud_db.db` ({tamanho_db})                         |
    | 📝 Arquivo de Log      | `log.txt` ({tamanho_log})                           |
    | 📁 Diretório           | `{os.path.dirname(os.path.abspath(__file__))}`      |
    """)

with col_tec2:
    # Exibe as últimas 10 linhas do log se ele existir
    if caminho_log.exists():
        st.markdown("**📝 Últimas entradas do Log:**")
        with open(caminho_log, "r", encoding="utf-8") as arquivo_log:
            linhas = arquivo_log.readlines()             # Lê todas as linhas do arquivo
            ultimas_linhas = linhas[-10:] if len(linhas) >= 10 else linhas  # Pega as últimas 10
        texto_log = "".join(ultimas_linhas)              # Junta as linhas em uma string
        st.code(texto_log, language=None)                # Exibe em bloco de código
    else:
        st.info("Log ainda não gerado.")  # Exibe aviso se o log não existir ainda

# ─── RODAPÉ ───────────────────────────────────────────────────────────────────
st.divider()
# Rodapé centralizado com os dados do sistema
st.markdown(f"""
<div style='text-align:center; color:#888; font-size:13px; padding:8px 0;'>
    {NOME_SISTEMA} {VERSAO} — Desenvolvido com Python + Streamlit + SQLite3<br>
    🎓 {INSTITUICAO} — {DISCIPLINA} | Aluno: {NOME_ALUNO} — {ANO}
</div>
""", unsafe_allow_html=True)
