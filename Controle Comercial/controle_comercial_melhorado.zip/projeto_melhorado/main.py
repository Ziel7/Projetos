# /////////////////////////////////////////////////////
# // Instituição  : SENAI
# // Disciplina   : Projeto Integrador
# // Nome Projeto : Controle Comercial
# // Aluno        : Gabriel Florentino
# // Data Atual   : 29/04/2026
# /////////////////////////////////////////////////////

"""
main.py - Ponto de entrada do sistema Controle Comercial
Responsável por configurar a página, verificar arquivos obrigatórios,
inicializar o banco de dados e exibir a tela inicial (Home).
"""

# ─── IMPORTAÇÃO DAS BIBLIOTECAS ────────────────────────────────────────────────
import streamlit as st    # Streamlit: cria a interface web do sistema
import logging            # logging: grava mensagens de erro e sucesso em arquivo de log
import os                 # os: interage com o sistema operacional (caminhos, pastas, variáveis)
from pathlib import Path  # Path: forma moderna e multiplataforma de manipular caminhos

# ─── CONSTANTES DO SISTEMA ─────────────────────────────────────────────────────
# Constantes são valores fixos definidos uma única vez.
# Facilita manutenção: se quiser mudar o nome do sistema, muda só aqui.

NOME_SISTEMA = "Controle Comercial"   # Nome exibido na interface e no título da aba
VERSAO       = "v1.0"                 # Versão atual do sistema
NOME_ALUNO   = "Gabriel Florentino"   # Nome do aluno desenvolvedor
INSTITUICAO  = "SENAI"                # Instituição de ensino
DISCIPLINA   = "Projeto Integrador"   # Nome da disciplina
ANO          = "2026"                 # Ano de desenvolvimento

# ─── CONFIGURAÇÃO DO STREAMLIT ─────────────────────────────────────────────────
# OBRIGATÓRIO: st.set_page_config() deve ser a primeira instrução Streamlit do script.
# Define o título da aba, ícone, layout e estado inicial da barra lateral.
st.set_page_config(
    page_title=NOME_SISTEMA,           # Título exibido na aba do navegador
    page_icon="🏪",                    # Ícone (emoji) da aba do navegador
    layout="wide",                     # Usa toda a largura da tela disponível
    initial_sidebar_state="expanded",  # Barra lateral começa aberta ao iniciar
)

# ─── CONFIGURAÇÃO DO LOGGING ──────────────────────────────────────────────────
# O módulo logging grava automaticamente eventos do sistema no arquivo log.txt.
# Registra erros, conexões, ações dos usuários e muito mais.
logging.basicConfig(
    filename="log.txt",                               # Nome do arquivo de log
    level=logging.INFO,                               # Registra INFO, WARNING, ERROR, CRITICAL
    format="%(asctime)s [%(levelname)s] %(message)s", # Formato da linha de log
    datefmt="%Y-%m-%d %H:%M:%S",                     # Formato da data e hora no log
    encoding="utf-8",                                 # UTF-8 para suportar acentos
)

# ─── USO DA BIBLIOTECA OS ─────────────────────────────────────────────────────
# os.path.abspath(__file__) → retorna o caminho ABSOLUTO deste arquivo no disco
# os.path.dirname()        → retorna apenas a PASTA onde o arquivo está
# Combinados, obtemos o diretório raiz do projeto de forma automática.
BASE_DIR_OS = os.path.dirname(os.path.abspath(__file__))

# Path(__file__).parent faz o mesmo usando pathlib (mais legível)
BASE_DIR = Path(__file__).parent

# Garante que a pasta de logs existe; cria se não existir.
# os.makedirs com exist_ok=True evita erro caso a pasta já exista.
os.makedirs(os.path.join(BASE_DIR_OS, "logs"), exist_ok=True)

# os.environ.get() lê uma variável de ambiente (se não existir, retorna "false")
# Útil para ativar modo de depuração sem alterar o código-fonte.
MODO_DEV = os.environ.get("MODO_DEV", "false").lower() == "true"

# ─── DICIONÁRIO DE ARQUIVOS OBRIGATÓRIOS ─────────────────────────────────────
# Dicionário: estrutura que associa uma CHAVE a um VALOR.
# Aqui: chave = nome amigável do módulo, valor = caminho do arquivo no disco.
ARQUIVOS_OBRIGATORIOS = {
    "Módulo Banco de Dados": BASE_DIR / "crud_db.py",
    "Página Clientes":       BASE_DIR / "pages" / "1_Clientes.py",
    "Página Produtos":       BASE_DIR / "pages" / "2_Produtos.py",
    "Página Vendas":         BASE_DIR / "pages" / "3_Vendas.py",
    "Página Relatórios":     BASE_DIR / "pages" / "4_Relatorios.py",
    "Página Sobre":          BASE_DIR / "pages" / "5_Sobre.py",
}

# Lista para acumular erros encontrados durante a verificação
erros_health = []

# Verifica se a pasta pages/ existe
if not (BASE_DIR / "pages").is_dir():
    erros_health.append("❌ Pasta `pages/` não encontrada!")

# Itera sobre o dicionário: para cada par (nome, caminho), verifica se o arquivo existe
for nome_modulo, caminho_arquivo in ARQUIVOS_OBRIGATORIOS.items():
    if not caminho_arquivo.exists():
        erros_health.append(f"❌ **{nome_modulo}** ausente: `{caminho_arquivo.name}`")

# Se encontrou algum erro, exibe todos e interrompe o sistema
if erros_health:
    st.error("## ⚠️ Falha no Health Check do Sistema")
    for erro in erros_health:
        st.write(erro)   # Exibe cada erro na tela
    st.stop()            # Interrompe a execução do Streamlit

# ─── INICIALIZAÇÃO DO BANCO DE DADOS ─────────────────────────────────────────
# Ao importar crud_db, a função inicializar_banco() é chamada automaticamente,
# criando as tabelas no SQLite se ainda não existirem.
try:
    import crud_db                                    # Importa e já inicializa o banco
    logging.info("Sistema iniciado com sucesso.")     # Registra no log o sucesso
except Exception as e:
    st.error(f"Erro ao conectar ao banco de dados: {e}")
    logging.critical(f"Erro crítico ao iniciar banco: {e}")
    st.stop()   # Para o sistema se o banco não puder ser acessado

# ─── CSS PERSONALIZADO ────────────────────────────────────────────────────────
# Injeta estilos CSS na página usando st.markdown com unsafe_allow_html=True.
# O CSS controla cores, fontes, sombras, animações e layout visual.
st.markdown("""
<style>
    /* Importa a fonte Inter do Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');

    /* Aplica a fonte em toda a página */
    html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

    /* Gradiente azul escuro na barra lateral */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    }

    /* Texto da barra lateral em cinza claro para boa legibilidade */
    [data-testid="stSidebar"] * { color: #e0e0e0 !important; }

    /* Botões com bordas arredondadas e animação suave */
    .stButton > button {
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.2s ease;
    }

    /* Eleva levemente os botões ao passar o mouse (hover) */
    .stButton > button:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }

    /* Cards de métricas com fundo suave e borda arredondada */
    [data-testid="metric-container"] {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 10px;
        padding: 12px;
    }

    /* Tabelas com cantos arredondados */
    .stDataFrame { border-radius: 10px; overflow: hidden; }

    /* Cards de navegação com animação ao passar o mouse */
    .nav-card {
        text-align: center;
        padding: 22px 10px;
        border-radius: 14px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .nav-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 16px rgba(0,0,0,0.12);
    }
</style>
""", unsafe_allow_html=True)

# ─── CABEÇALHO DA TELA INICIAL ────────────────────────────────────────────────
logo_path = BASE_DIR / "logo.jpg"  # Caminho esperado para a imagem de logo

# Divide o topo em 2 colunas: uma pequena para a logo e uma grande para o título
col_logo, col_titulo = st.columns([1, 5])

with col_logo:
    if logo_path.exists():
        st.image(str(logo_path), width=90)  # Exibe a logo se o arquivo existir
    else:
        # Se não houver logo, usa um emoji grande como substituto visual
        st.markdown("<div style='font-size:64px; text-align:center;'>🏪</div>",
                    unsafe_allow_html=True)

with col_titulo:
    st.markdown(f"# {NOME_SISTEMA}")
    st.markdown("##### Sistema de gestão de clientes, produtos e vendas")
    # Exibe créditos usando as constantes definidas no topo do arquivo
    st.caption(f"🎓 {INSTITUICAO} — {DISCIPLINA} | Aluno: {NOME_ALUNO} | {VERSAO} | {ANO}")

st.divider()  # Linha horizontal separadora

# ─── CARDS DE NAVEGAÇÃO RÁPIDA ───────────────────────────────────────────────
st.markdown("### 📌 Navegação Rápida")
st.markdown("Use o **menu lateral** à esquerda para navegar entre as seções:")

# Dicionário com os dados visuais de cada card de navegação
# Chave = identificador, Valor = dicionário com ícone, título, descrição e cor
CARDS_NAVEGACAO = {
    "clientes":   {"icone": "👤", "titulo": "Clientes",   "desc": "Cadastro e gestão",   "cor": "#e3f2fd"},
    "produtos":   {"icone": "📦", "titulo": "Produtos",   "desc": "Estoque e preços",    "cor": "#e8f5e9"},
    "vendas":     {"icone": "💰", "titulo": "Vendas",     "desc": "Registro de vendas",  "cor": "#fff3e0"},
    "relatorios": {"icone": "📈", "titulo": "Relatórios", "desc": "Análises e filtros",  "cor": "#fce4ec"},
    "sobre":      {"icone": "ℹ️", "titulo": "Sobre",      "desc": "Sobre o sistema",     "cor": "#f3e5f5"},
}

# Cria 5 colunas iguais e renderiza um card HTML em cada uma
colunas_nav = st.columns(5)
for col, (_, card) in zip(colunas_nav, CARDS_NAVEGACAO.items()):
    with col:
        st.markdown(f"""
        <div class='nav-card' style='background:{card["cor"]};'>
            <div style='font-size:2.2rem;'>{card["icone"]}</div>
            <strong style='font-size:0.95rem;'>{card["titulo"]}</strong>
            <p style='font-size:0.75rem; color:#666; margin:4px 0 0;'>{card["desc"]}</p>
        </div>
        """, unsafe_allow_html=True)

st.divider()

# ─── RESUMO GERAL (MÉTRICAS DO BANCO) ────────────────────────────────────────
# Consulta o banco de dados e exibe os totais em tempo real.
st.markdown("### 📊 Resumo Geral")

try:
    # len() conta quantos registros a função select() retornou de cada tabela
    total_clientes = len(crud_db.select("clientes"))   # Total de clientes
    total_produtos = len(crud_db.select("produtos"))   # Total de produtos
    total_vendas   = len(crud_db.select("vendas"))     # Total de vendas

    # Usa SQL com SUM() para somar todos os valores da coluna "total" em vendas
    vendas_dados = crud_db.select("vendas", colunas="SUM(total) as faturamento")
    faturamento  = vendas_dados[0].get("faturamento") or 0.0  # None vira 0.0

    # st.columns(4) cria 4 colunas iguais para exibir as métricas lado a lado
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("👤 Clientes Cadastrados", total_clientes)
    m2.metric("📦 Produtos no Catálogo",  total_produtos)
    m3.metric("💰 Vendas Realizadas",     total_vendas)
    m4.metric("💵 Faturamento Total",     f"R$ {faturamento:,.2f}")  # :,.2f formata com separador de milhar

except Exception as e:
    st.warning(f"Não foi possível carregar o resumo: {e}")

# ─── INFORMAÇÕES DO AMBIENTE (OS) ─────────────────────────────────────────────
# st.expander cria um bloco recolhível — o usuário clica para expandir
with st.expander("🖥️ Informações do Ambiente de Execução"):
    col_env1, col_env2 = st.columns(2)

    # Caminho completo do banco de dados para verificar tamanho
    caminho_db = os.path.join(BASE_DIR_OS, "crud_db.db")

    with col_env1:
        st.markdown(f"**📁 Diretório do projeto:** `{BASE_DIR_OS}`")
        st.markdown(f"**📂 Diretório atual:** `{os.getcwd()}`")  # os.getcwd() = pasta atual de execução
    with col_env2:
        # os.path.exists() verifica se o arquivo existe antes de tentar ler seu tamanho
        if os.path.exists(caminho_db):
            tamanho_kb = os.path.getsize(caminho_db) / 1024  # os.path.getsize() retorna tamanho em bytes
            st.markdown(f"**🗄️ Tamanho do banco:** `{tamanho_kb:.2f} KB`")
        else:
            st.markdown("**🗄️ Banco de dados:** `ainda não criado`")
        st.markdown(f"**🔧 Modo desenvolvimento:** `{'Ativo' if MODO_DEV else 'Inativo'}`")

# ─── RODAPÉ ───────────────────────────────────────────────────────────────────
st.markdown("---")
# Texto centralizado com informações do sistema e créditos do projeto
st.markdown(f"""
<div style='text-align:center; color:#888; font-size:13px; padding:8px 0;'>
    {NOME_SISTEMA} {VERSAO} — Desenvolvido com Python + Streamlit + SQLite3<br>
    🎓 {INSTITUICAO} — {DISCIPLINA} | Aluno: {NOME_ALUNO} — {ANO}
</div>
""", unsafe_allow_html=True)
